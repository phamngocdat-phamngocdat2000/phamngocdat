<?php

return [
    'scripts' => [
        'plugins/datatables/jquery.dataTables.min.js',
        "plugins/datatables-bs4/js/dataTables.bootstrap4.min.js",
        "plugins/datatables-responsive/js/dataTables.responsive.min.js",
        "plugins/datatables-responsive/js/responsive.bootstrap4.min.js",
        "plugins/datatables-buttons/js/dataTables.buttons.min.js",
        "plugins/datatables-buttons/js/buttons.bootstrap4.min.js"
    ]
]

?>
